@extends('layouts.profile.home')
   @section('content')
        <div class="section-main section-minimal">
            <center>
                <div class="container-small lr-change-password">
                    <center><table>
                            <tr><td>Old Password: </td><td><input name="email" type='password' id='user-changepassword-oldpassword'/></td></tr>
                            <tr><td>New Password: </td><td><input name="email" type='password' id='user-changepassword-newpassword'/></td></tr>
                        </table></center>
                    <button id="btn-user-changepassword">Change Password</button><br/>
                    <span style="color:red" id="user-changepassword-errorMsg"></span>
                    <span style="color:green" id="user-changepassword-successMsg"></span>
                </div>
            </center>                
        </div>       
    @endsection