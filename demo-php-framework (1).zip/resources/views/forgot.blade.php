@extends('layouts.home')
@section('content')
        <div class="section-main section-minimal">
            <center>
                <div class="container-small lrforgotpassword" style="display:block;">
                    <center><table>
                            <tr><td>Email Address: </td><td><input name="email" type='text' id='minimal-forgotpassword-email'/></td></tr>
                        </table></center>
                    <button id="btn-minimal-forgotpassword">Send</button><br/>
                    <span style="color:red" id="minimal-forgotpassword-errorMsg"></span>
                    <span style="color:green" id="minimal-forgotpassword-successMsg"></span>
                </div>

                <div class="container-small lrrestpassword" style="display:none;">
                    Password: <input name="email" type='password' id='minimal-resetpassword-password'/><br/>
                    Confirm Password: <input name="email" type='password' id='minimal-resetpassword-confirmpassword'/><br/>
                    <button id="btn-minimal-resetpassword">Reset Password</button><br/>
                    <span style="color:red" id="minimal-resetpassword-errorMsg"></span>
                    <span style="color:green" id="minimal-resetpassword-successMsg"></span>
                </div>
            </center>                
        </div>       
  @endsection