@extends('layouts.app')

@section('content')
hi there

@endsection